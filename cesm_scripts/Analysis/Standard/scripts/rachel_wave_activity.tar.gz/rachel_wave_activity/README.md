Scripts in ./nishii_scripts are verbatim from: http://www.atmos.rcast.u-tokyo.ac.jp/nishii/programs/index.html
Scripts in ./ncl_ncep are based on the nishii scripts, but actually work and loop over all years from NCEP-II.
Scripts in ./mat just make some climatological figures --- contour plots of the different WAF components, the basic state winds, and vector plots of the horizontal WAF components. Plots are done for each month.
./lib has some plotting routines for convenience.